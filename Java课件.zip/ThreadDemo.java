package PPT_Question;
class Lock {
	int Lock_int = 0;
	Integer Lock_Integer = 0;
}
class CountDown2 extends Thread{
	private static int idcnt=1;
	private final int threadid=idcnt++;
	int counter=3;
	Lock synLock = new Lock();
	String a = "";
	public void run(){
		Integer b= 0;
//		b= 1;
		b = new Integer(counter);
		if (threadid == 1)
		{
//			a= "123";
			b = 1;
			synchronized (b) {
				b=2;
				while(counter>=0){
					try{ 
						Thread.sleep(1000);
					} catch (Exception e){ e.printStackTrace(); }
			
					System.out.println("#"+threadid+(counter>0?"->"+counter:"->run!"));
					counter--;
				}
			}
		}

		else
		{
			b=1;
			synchronized (b) {
				
				while(counter>=0){
					try{ 
						Thread.sleep(1000);
					} catch (Exception e){ e.printStackTrace(); }
			
					System.out.println("#"+threadid+(counter>0?"->"+counter:"->run!"));
					counter--;
				}
			}
		}

	}
}	

public class ThreadDemo {
	private static int idcnt=1;
	private final int threadid=idcnt++;
	int counter=3;
	public void run(){
		while(counter>=0){
			try{ 
				Thread.sleep(1000);
			} catch (Exception e){ e.printStackTrace(); }
			System.out.println("#"+threadid+
				(counter>0?"->"+counter:"->run!"));
			counter--;
		}
	}
	public static void main(String[] args){
		CountDown2 t1=new CountDown2();
		Thread t2=new CountDown2();
		t1.start();
		t2.start();
		System.out.println("waiting for run...");
	}

}
