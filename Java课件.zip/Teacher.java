package test1;

public class Teacher extends Normal {
    private String name;//����
    private int age;//
    private int StuNumber;
 
	public Teacher(int h, int w, String n, int a,int S) 
	{
		super(n, w, h, a);
		this.StuNumber=S;
	}	
 
    public void doteach() 
    {
        System.out.println(name+"���ڽ���");
    }

}
