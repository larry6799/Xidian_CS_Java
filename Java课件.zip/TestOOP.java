class mytime{
private int hour;
private int min;

public String getTime(){
	return hour+":"+min+"/";
}
public int getHour(){
	return this.hour;
}
public int getMin(){
	return this.min;
}
public mytime(int a,int b){
if((a>0)&&(a<24)&&(b>0)&&(b<60)){
this.hour=a;
this.min=b;
}
}
}
abstract class norperson{
String name;
String sex;
protected norperson(String name,String sex){
this.name=name;
this.sex=sex;
} 
abstract void takeBus(int x,int fee,String area);
abstract int sleep(int x,int y);
public String getInformation(String name){
return " name: "+name+"\nsex "+sex;
}
}
class teacher{
public String name;
public String sex;
public String Dept;
public teacher(String name,String sex,String Dept){
this.name=name;
this.sex=sex;
this.Dept=Dept;
} 
public String getDetail(String name){
return name+"\n"+sex+"\n"+Dept;
}
public  boolean isFree(mytime x){
	
mytime i=new mytime(8,30);
mytime j=new mytime(17,30);
if((x.getHour()>i.getHour())&&(x.getMin()>i.getMin())&&(x.getHour()<j.getHour())&&(x.getMin()<j.getMin()))
return true;
else
return false;
}
}
class student{
public String name;
public String sex;
public String faculty;
public  student(String name,String sex,String faculty){
this.name=name;
this.sex=sex;
this.faculty=faculty;
} 
public  boolean isFree(mytime x){
	
mytime i=new mytime(8,30);
mytime j=new mytime(17,30);
if((x.getHour()>i.getHour())&&(x.getMin()>i.getMin())&&(x.getHour()<j.getHour())&&(x.getMin()<j.getMin()))
return true;
else
return false;
}

public boolean isfac(String aFaculty){
if(this.faculty.equals(aFaculty)){
return true;
}
else 
return false;
}
}
class school{
private String name;
private String area;
private int type;
private int numMou;
public  school(String name,String area,int type,int numMou){
this.name=name;
this.area=area;
this.type=type;
this.numMou=numMou;
}
public String getDetail(){
return name+"at "+area+" is"+type+"school "+numMou+" people";
}
public void acceptSb(student Sb){
this.numMou++;
}
public void delSb(student Sb){
this.numMou--;
}
}