public class MyRunnable implements Runnable{
    private int Ticket;
    public MyRunnable(int Ticket) {
        this.Ticket = Ticket;
    }
    public void run() {
        int num = Ticket;
        for(int i=0;i<(int)num/3+1;i++)
            tell();
    }
    public synchronized void tell(){
 
        if(Ticket>0)
        {
            /*try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }*/
            System.out.println("����"+Thread.currentThread().getName()+"���۱��"+Ticket--+"��ӰƱ");
        }           
    }
}
public class TicketDemo1 {
 
    public static void main(String[] args) {
        MyRunnable mr1 = new MyRunnable(100);
 
        Thread t1 = new Thread(mr1,"һ��");
        Thread t2 = new Thread(mr1,"����");
        Thread t3 = new Thread(mr1,"����");
 
        t1.start();
        t2.start();
        t3.start();
 
    }
 
}