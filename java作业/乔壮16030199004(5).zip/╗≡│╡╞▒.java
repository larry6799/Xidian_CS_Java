/**
 * Created by  Rui Zhang on 2017/6/17.
 */
import java.util.Scanner;

public class saleticket {
    public static int k=0;//�ܳ�Ʊ��
    public  static synchronized void sell(int m,int n){
        k+=m;
        System.out.println(n+"����Ʊ���ڳ��۱��Ϊ"+k+"�ĵ�ӰƱ");
    }
    public static class Seller extends Thread{
        public int n;//��Ʊ��
        public Seller(int n){
            this.n=n;
        }

        public void run(){
            for(int i=0;i<3;i++){
                sell(1,n);

                try {
                    Thread.sleep(1);
                }
                catch(InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
    }
    public static void main(String[] args) {
        System.out.println("�����Ա�������ĵ�ӰƱ����");
        Scanner sc = new Scanner(System.in);
        int v = sc.nextInt();

        int count =v/9;
        int count1 = v%9;
        int count2 = count1/3;
        int count3 =count1%3;

        System.out.println("ʵʱ��Ʊ�������:");
        for(int q=0;q<count;q++){
            for(int i=1;i<=3;i++)
                new Seller(i).start();

        }
        for(int i=0;i<count2;i++){
            for(int q=1;q<=3;q++)
                System.out.println((int)(1+Math.random()*(3-1+1))+"�Ŵ��ڳ��۱��Ϊ"+(count*9+3*i+q)+"��ӰƱ");
        }
        for(int i=1;i<=count3;i++){
                System.out.println((int)(1+Math.random()*(3-1+1))+"�Ŵ��ڳ��۱��Ϊ"+(count*9+count2*3+i)+"��ӰƱ");
        }
        sc.close();
    }

}