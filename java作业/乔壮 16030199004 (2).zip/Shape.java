package com.hopepower.myshape;

public class Shape {

    private String name;

    public Shape(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static String getThisClass(Object o) {
        if (o instanceof Circle)
            return "Circle";
        else if (o instanceof Rectangle)
            return "Rectangle";
        else
            return "Triangle";
    }
}
