package com.hopepower.myshape;

public class Triangle extends Shape {

    public Triangle(String name) {
        super(name);
    }

}
