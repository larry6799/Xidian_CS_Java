package com.hopepower.myshape;

public class Rectangle extends Shape {

    public Rectangle(String name) {
        super(name);
    }
}
