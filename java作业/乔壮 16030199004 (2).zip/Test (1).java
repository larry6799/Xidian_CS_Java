﻿package com.hopepower.myshape;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        List<Shape> shapes = new ArrayList<Shape>();
        for (int i = 0; i < 20; i++) {
            System.out.println("请输入命令（1为矩形，2为圆形，3为三角形,0退出创建）");
            int code = new Scanner(System.in).nextInt();
            if (code != 0)
                System.out.println("请输入绘制图形的名字");
            else
                break;
            String name = new Scanner(System.in).nextLine();
            switch (code) {
                case 1:
                    shapes.add(new Rectangle(name));
                    break;
                case 2:
                    shapes.add(new Circle(name));
                    break;
                case 3:
                    shapes.add(new Triangle(name));
                    break;
            }
        }
        while (true) {
            System.out.println("请输入命令（1、查找 2、开始绘制)");
            int code = new Scanner(System.in).nextInt();
            if (code == 1) {
                System.out.println("输入你要查找的图形名");
                String findName = new Scanner(System.in).nextLine();
                for (Shape shape : shapes) {
                    if (shape.getName().equals(findName)) {
                        System.out.println(shapes.indexOf(shape) + 1 + " " + Shape.getThisClass(shape));
                    }
                }
            } else {
                System.out.println("绘制几个图形");
                int count = new Scanner(System.in).nextInt();
                for (int i = 0; i < count; i++) {
                    System.out.println(i + 1 + " " + Shape.getThisClass(shapes.get(i)) + " "+ shapes.get(i).getName());
                }
            }
        }
    }
}
