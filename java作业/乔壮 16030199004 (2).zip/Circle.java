package com.hopepower.myshape;

/**
 * Created by 12531 on 2017/5/22.
 */
public class Circle extends Shape {

    public Circle(String name) {
        super(name);
    }

}
