package trip;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;  
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
  
public class Manager extends JFrame{  
    
	
	private DefaultListModel<ScenicSpots> scModel;
	private DefaultListModel<String> jiaoTong;
	private DefaultListModel<TravelItem> traModel;
	private DefaultListModel<String> itemName;
	
	
	   
    private JTextField textField1;
    private JTextField textField2; 
    private JTextField textField3; 
    private JTextField textField4; 
    private JTextField textField5; 
    private JTextField textField6; 
    private JTextField textField7;
    private JTextField textField8; 
    private JTextField textField9; 
    private JButton buttonUpdate;
    private JButton buttonUpdate1;
    
    private JTextField itextField1;
    private JTextField itextField2;
    private JTextField itextField30;
    private JTextField itextField31;
    private JButton buttonAddItem;
    private JButton buttonRemoveItem;
    private int listIndex;
    private JList list;
    
    private JTextField tTextField1;
    private JButton buttonAddTf;
    private JButton buttonRemoveTf;
    private int listIndex1;
    private JList list1;
    
    private JList listSc;
    
    private ArrayList<ScenicSpots> dataBase;
    DefaultListModel<String> copyofItemName = null;
    DefaultListModel<String> copyOFTf = null;
 
    public Manager(DefaultListModel<ScenicSpots> dataBase, DefaultListModel<String> scName){ 
    	
    	this.scModel = dataBase;
    	jiaoTong = new DefaultListModel<String>();
    	traModel = new DefaultListModel<TravelItem>();
    	itemName = new DefaultListModel<String>();
		initGUI();
		buttonUpdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			   Boolean success = false;
			   double xtemp;
			   double yTemp;
			   double priceTemp;
			   try {
				xtemp = Double.parseDouble(textField5.getText());
				yTemp = Double.parseDouble(textField6.getText());
				priceTemp = Double.parseDouble(textField8.getText());
				ScenicSpots cSpots = new ScenicSpots(textField1.getText(),
						   textField4.getText(), xtemp, yTemp, 
						   textField2.getText(), textField3.getText(), textField7.getText(),priceTemp, textField9.getText(), jiaoTong,traModel, itemName);
				scModel.addElement(cSpots);
				scName.addElement(textField1.getText());
				success = true;
			} catch (NumberFormatException e2) {
				
				System.out.println("��������");
			}
			if(success)   
			{  textField1.setText("");
			   textField2.setText("");
			   textField3.setText("");
			   textField4.setText("");
			   textField5.setText("");
			   textField6.setText("");
			   textField7.setText("");
			   textField8.setText("");
			   textField9.setText("");
			   
			   itextField1.setText("");
			   itextField2.setText("");
			   itextField30.setText("");
			   itextField31.setText("");
			   
			   tTextField1.setText("");
			   
			   jiaoTong = null;
			   traModel = null;
			   itemName = null;
			   jiaoTong = new DefaultListModel<String>();
		       traModel = new DefaultListModel<TravelItem>();
		       itemName = new DefaultListModel<String>();
		       copyofItemName.clear();
		       copyOFTf.clear();
		       
		     
		    	System.out.println(scModel.size());
			   
			}
			}
		});
		buttonAddItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean success = false;
				Double priceTemp;
				Integer integer1;
				Integer integer2;
				 try {
					 priceTemp = Double.parseDouble(itextField2.getText());
					 integer1 = Integer.parseInt(itextField30.getText());
					 integer2 = Integer.parseInt(itextField31.getText());
					 TravelItem travelItem =
								new TravelItem(itextField1.getText(), priceTemp, integer1,integer2 );
					traModel.addElement(travelItem);
					itemName.addElement(itextField1.getText());
					copyofItemName.addElement(itextField1.getText());
					success = true;
					} catch (NumberFormatException e2) {
						
						System.out.println("��������");
					}
				
				if(success)
				{  itextField1.setText("");
				   itextField2.setText("");
				   itextField30.setText("");
				   itextField31.setText("");
				}
			}
		}); 
		buttonAddTf.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jiaoTong.addElement(tTextField1.getText());
				copyOFTf.addElement(tTextField1.getText());
				tTextField1.setText("");
			}
		});
		buttonRemoveItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				listIndex = list.getSelectedIndex();
				traModel.remove(listIndex);
				itemName.remove(listIndex);
			}
		});
		buttonRemoveTf.addActionListener(new ActionListener() {
	
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				listIndex1 = list1.getSelectedIndex();
				jiaoTong.remove(listIndex1);
			}
		});      
    }  
	public void initGUI()
	{
		 this.setTitle("�����¾���");  
	        this.setLayout(new BorderLayout());
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);  
	        this.setBounds(200, 200, 800, 500);
	        JPanel contentPane=new JPanel();  
	        contentPane.setBorder(new EmptyBorder(5,5,5,5));  
	        contentPane.setLayout(new GridLayout(6,2, 1,1));  
	        JPanel pane1=new JPanel();  
	        contentPane.add(pane1);  
	        JPanel pane2=new JPanel();  
	        contentPane.add(pane2);  
	        JPanel pane3=new JPanel();  
	        contentPane.add(pane3);  
	        JPanel pane4=new JPanel();  
	        contentPane.add(pane4); 
	        JPanel pane5=new JPanel();  
	        contentPane.add(pane5);  
	        JPanel pane6=new JPanel();  
	        contentPane.add(pane6);  
	        JLabel label1=new JLabel("��������");      
	        textField1=new JTextField();  
	        textField1.setColumns(10);  
	        pane1.add(label1);  
	        pane1.add(textField1);  
	        JLabel label2=new JLabel("�ſ���");  
	        textField2=new JTextField();  
	        textField2.setColumns(5);  
	        pane2.add(label2);  
	        pane2.add(textField2);  
	        JLabel label3=new JLabel("���飺");  
	        textField3=new JTextField();  
	        textField3.setColumns(5);  
	        pane2.add(label3);  
	        pane2.add(textField3);   
	        
	        JLabel label7=new JLabel("ס�ޣ�");  
	        textField7=new JTextField();  
	        textField7.setColumns(5);  
	        pane3.add(label7);  
	        pane3.add(textField7);  
	        JLabel label8=new JLabel("ס�޼۸�");  
	        textField8=new JTextField();  
	        textField8.setColumns(5);  
	        pane3.add(label8);  
	        pane3.add(textField8);   
	        
	        
	        
	        
	        JLabel label9=new JLabel("���Σ�");  
	        textField9=new JTextField();  
	        textField9.setColumns(5);
	        JLabel label4=new JLabel("��ַ��");  
	        textField4=new JTextField();  
	        textField4.setColumns(10);
	        pane4.add(label9);  
	        pane4.add(textField9);
	        pane4.add(label4);  
	        pane4.add(textField4);  


	        JLabel label5=new JLabel("����X��");  
	        textField5=new JTextField(); 
	        textField5.setColumns(5);
	        JLabel label6=new JLabel("����y��");  
	        textField6=new JTextField(); 
	        textField6.setColumns(5);
	        pane5.add(label5);  
	        pane5.add(textField5); 
	        pane5.add(label6);  
	        pane5.add(textField6); 
	        
	        buttonUpdate = new JButton("ȷ������");
	        
	        pane6.add(buttonUpdate); 
	     
	        
	      /******************���뾰��ľ�����Ŀ**********************/  
	        
	        
	        JPanel itemContentPane=new JPanel();  
	        itemContentPane.setBorder(new EmptyBorder(5,5,5,5)); 
	        itemContentPane.setLayout(new GridLayout(4,2, 1,1));
	        JPanel ipane1=new JPanel();  
	        itemContentPane.add(ipane1);  
	        JPanel ipane2=new JPanel();  
	        itemContentPane.add(ipane2);  
	        JPanel ipane3=new JPanel();  
	        itemContentPane.add(ipane3);  
	        JPanel ipane4=new JPanel();  
	        itemContentPane.add(ipane4); 
	        JLabel ilabel1=new JLabel("���ݣ�");      
	        itextField1=new JTextField();  
	        itextField1.setColumns(10);  
	        ipane1.add(ilabel1);  
	        ipane1.add(itextField1);  
	        JLabel ilabel2=new JLabel("�۸�");  
	        itextField2=new JTextField();  
	        itextField2.setColumns(10);  
	        ipane2.add(ilabel2);  
	        ipane2.add(itextField2);  
	        JLabel ilabel3=new JLabel("ʱ��(Сʱ/���ӣ���");  
	        itextField30=new JTextField();  
	        itextField30.setColumns(2);  
	        itextField31=new JTextField();  
	        itextField31.setColumns(2);  
	        ipane3.add(ilabel3);  
	        ipane3.add(itextField30);  
	        ipane3.add(itextField31);
	        buttonAddItem = new JButton("����");
	        buttonRemoveItem = new JButton("ɾ��ѡ����");
	        
	        DefaultListModel<String> model = new DefaultListModel<>();
	        
	        ipane4.add(buttonAddItem);
	        ipane4.add(buttonRemoveItem);
	        
	        copyofItemName = new DefaultListModel<String>();
	        list = new JList(copyofItemName);
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			list.setSelectedIndex(0);
			list.setVisibleRowCount(6);
			list.setSize(200, 800);
			JScrollPane listScrollPane = new JScrollPane(list);
	        
	        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
	        		listScrollPane,itemContentPane);
	        
	        
	        /*************************���ӽ�ͨ����************************/
	        
	        JPanel tContentPane=new JPanel();  
	        tContentPane.setBorder(new EmptyBorder(5,5,5,5)); 
	        tContentPane.setLayout(new GridLayout(2,2, 1,1));
	        JPanel tJpanel1 =new JPanel();  
	        tContentPane.add(tJpanel1);  
	        JPanel tJPanel2 =new JPanel();  
	        tContentPane.add(tJPanel2);  
	        
	        JLabel ilabel11=new JLabel("��ͨ���ߣ�");      
	        tTextField1=new JTextField();  
	        tTextField1.setColumns(10);  
	        tJpanel1.add(ilabel11);  
	        tJpanel1.add(tTextField1); 
	        buttonAddTf = new JButton("����");
	        buttonRemoveTf = new JButton("ɾ��ѡ����");
	        
	        tJPanel2.add(buttonAddTf);
	        tJPanel2.add(buttonRemoveTf);
	        
	        copyOFTf = new DefaultListModel<String>();
		    
	        list1 = new JList(copyOFTf);
			list1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			list1.setSelectedIndex(0);
			list1.setVisibleRowCount(6);
			list1.setSize(200, 800);
			JScrollPane listScrollPane1 = new JScrollPane(list1);
			
			JSplitPane splitPane1 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
	        		listScrollPane1,tContentPane);
			
			
			JSplitPane verJSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
					splitPane,splitPane1);
			
			JSplitPane splitPaneTotal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
	        		contentPane,verJSplitPane);
			
			
			listSc = new JList(scModel);
			listSc.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			listSc.setSelectedIndex(0);
			listSc.setVisibleRowCount(6);
			JScrollPane listScrollPaneSc = new JScrollPane(listSc);
			this.add(splitPaneTotal,"Center");
			this.add(listScrollPaneSc,"West");
	}
}  
