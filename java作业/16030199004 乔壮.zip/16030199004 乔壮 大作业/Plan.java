package trip;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Plan {

	private DefaultListModel<ScenicSpots> traListModel;
	private DefaultListModel<String> tf;
	private double TotalPrice;
	private String rString;
	public Plan(DefaultListModel<ScenicSpots> traListModel, DefaultListModel<String> tf) {
		this.traListModel = traListModel;
		this.tf = tf;
	}
	
	public String displayPlan()
	{
		int totalPrice;
		StringBuilder  rBuilder = new StringBuilder();
		for (int i = 0; i < traListModel.size(); i++)
		{
			int hour = 0;
			int minute = 0;
			double price = 0;
			ScenicSpots  scenicSpots = traListModel.get(i);
			rBuilder.append("��"+(i+1)+"վ��");
			rBuilder.append("����" + tf.get(i) + "ǰ��" + scenicSpots.getName() +",����"+scenicSpots.getDaoyou()
			+"������������ ");
			DefaultListModel<TravelItem> aDefaultListModel = scenicSpots.getTravelItems();
			for (int j = 0; j < aDefaultListModel.size();j++)
			{
				rBuilder.append(aDefaultListModel.get(j).getName()+",");
				hour += aDefaultListModel.get(j).getHour();
				minute += aDefaultListModel.get(j).getMinutes();
				price += aDefaultListModel.get(j).getPrice();
			}
			hour += minute / 60;
			minute = minute % 60;
			price += scenicSpots.getZhusuPrice();
			TotalPrice += price;
			rBuilder.append("����Ŀ.Ԥ��ʱ��" + hour + "Сʱ" + minute + "�֣���" + scenicSpots.getZhusu() + "��Ϣ����Щ��ĿԤ�ƻ���" + price + "Ԫ\n");
		}
		
		rBuilder.append("����γ��в��㳵��Ԥ�ƻ�" + TotalPrice + "Ԫ");
		rString = rBuilder.toString();
		return rString;
	}
	

	
}

