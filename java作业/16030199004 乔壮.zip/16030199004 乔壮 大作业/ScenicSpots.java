package trip;

import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.event.ListSelectionListener;

public class ScenicSpots {
	private String name;
	private String address;
	private double x;
	private double y;
	private String overView;
	private String details;
	private String zhusu;
	private String daoyou;
	private Double zhusuPrice;
	public Double getZhusuPrice() {
		return zhusuPrice;
	}
	public void setZhusuPrice(Double zhusuPrice) {
		this.zhusuPrice = zhusuPrice;
	}
	public DefaultListModel<String> getItemName() {
		return itemName;
	}
	public void setItemName(DefaultListModel<String> itemName) {
		this.itemName = itemName;
	}
	private DefaultListModel<String> jiaotong;
	private DefaultListModel<TravelItem> travelItems;
	private DefaultListModel<String> itemName;
	
	public ScenicSpots(String name, String address, double x, double y, String overView, String details, String zhusu,
			Double zhusuPrice,
			String daoyou, DefaultListModel<String> jiaotong, DefaultListModel<TravelItem> travelItems,
			DefaultListModel<String> itemName) {
		super();
		this.name = name;
		this.address = address;
		this.x = x;
		this.y = y;
		this.overView = overView;
		this.details = details;
		this.zhusu = zhusu;
		this.zhusuPrice = zhusuPrice;
		this.daoyou = daoyou;
		this.jiaotong = jiaotong;
		this.travelItems = travelItems;
		this.itemName = itemName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getOverView() {
		return overView;
	}
	public void setOverView(String overView) {
		this.overView = overView;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getZhusu() {
		return zhusu;
	}
	public void setZhusu(String zhusu) {
		this.zhusu = zhusu;
	}
	public String getDaoyou() {
		return daoyou;
	}
	public void setDaoyou(String daoyou) {
		this.daoyou = daoyou;
	}
	
	public DefaultListModel<String> getJiaotong() {
		return jiaotong;
	}
	public void setJiaotong(DefaultListModel<String> jiaotong) {
		this.jiaotong = jiaotong;
	}
	public DefaultListModel<TravelItem> getTravelItems() {
		return travelItems;
	}
	public void setTravelItems(DefaultListModel<TravelItem> travelItems) {
		this.travelItems = travelItems;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		
		return name;
	}
	public String myToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("������  "+ name +" \n");
		stringBuilder.append("�ſ� "+ overView + "\n");
		stringBuilder.append("��ַ  "+ address +" \n");
		stringBuilder.append("���� "+ details + "\n");
		stringBuilder.append("ס�� "+ name  + " ��λ:" + zhusuPrice + " \n");
		stringBuilder.append("���� "+ daoyou + "\n");
		stringBuilder.append("��ͨ��ʽ:");
		if (jiaotong != null)
		{
			for (int i = 0; i < jiaotong.size(); i++)
				stringBuilder.append(jiaotong.get(i) + "/");
		}
		stringBuilder.append("\n \n");
		stringBuilder.append("������Ŀ���£�\n");
		if (travelItems != null)
		{
			for (int i = 0; i < travelItems.size(); i++)
				stringBuilder.append(travelItems.get(i).toMyString() + "\n");
		}
		
		return stringBuilder.toString();
		
	}

}

