package trip;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ManagerAddTf extends JFrame{
	private JList listSc;
	private JList listTf;
	private DefaultListModel<String> scName;
	private DefaultListModel<String> tfName;
	private DefaultListModel<ScenicSpots> scModel;
	private JTextField tTextField1;
	public void initGUI()
	{
		    this.setTitle("���ӽ�ͨ����");  
	        this.setLayout(new BorderLayout());
	        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);  
	        this.setBounds(200, 200, 600, 300);
	        JPanel contentPane=new JPanel();  
	        contentPane.setBorder(new EmptyBorder(5,5,5,5));  
	        contentPane.setLayout(new GridLayout(6,2, 1,1));  
	        scName = new DefaultListModel<String>();
	        for (int i = 0; i < scModel.size(); i++)
	        {
	        	scName.addElement(scModel.get(i).getName());
	        }
	        listSc = new JList(scName);
			listSc.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			listSc.setSelectedIndex(0);
			listSc.setVisibleRowCount(6);
			
			listSc.addListSelectionListener(new ListSelectionListener() {
				
				private DefaultListModel<String> tf;

				@Override
				public void valueChanged(ListSelectionEvent e) {
					// TODO Auto-generated method stub
					int index = listSc.getSelectedIndex();
					tf = scModel.get(index).getJiaotong();
					tfName.clear();
					for (int i = 0; i<tf.size();i++)
					{
						tfName.addElement(tf.get(i));
					}
				}
			});
			JScrollPane listScrollPaneSc = new JScrollPane(listSc);
			tfName = new DefaultListModel<String>();
			listTf = new JList(tfName);
			listTf.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			listTf.setSelectedIndex(0);
			listTf.setVisibleRowCount(6);
			
			
			JPanel tContentPane=new JPanel();  
	        tContentPane.setBorder(new EmptyBorder(5,5,5,5)); 
	        tContentPane.setLayout(new GridLayout(2,2, 1,1));
	        JPanel tJpanel1 =new JPanel();  
	        tContentPane.add(tJpanel1);  
	        JPanel tJPanel2 =new JPanel();  
	        tContentPane.add(tJPanel2);  
	        
	        JLabel ilabel11=new JLabel("��ͨ���ߣ�");      
	        tTextField1 = new JTextField();  
	        tTextField1.setColumns(10);  
	        tJpanel1.add(ilabel11);  
	        tJpanel1.add(tTextField1); 
	        JButton buttonAddTf = new JButton("����");
	        buttonAddTf.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					int indexTotal = listSc.getSelectedIndex();
					DefaultListModel<String> jModel = scModel.get(indexTotal).getJiaotong();
					jModel.addElement(tTextField1.getText());
					tfName.addElement(tTextField1.getText());
				}
			});
	        JButton buttonRemoveTf = new JButton("ɾ��ѡ����");
	        buttonRemoveTf.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					int indexTotal = listSc.getSelectedIndex();
					DefaultListModel<String> jModel = scModel.get(indexTotal).getJiaotong();
					jModel.remove(listTf.getSelectedIndex());
					tfName.remove(listTf.getSelectedIndex());
				}
			});
	        tJPanel2.add(buttonAddTf);
	        tJPanel2.add(buttonRemoveTf);
	        
            JScrollPane listScrollPane1 = new JScrollPane(listTf);
			
			JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
	        		listScrollPane1,tContentPane);			
			
			JScrollPane listScrollPane = new JScrollPane(listSc);
			this.add(listScrollPane,"West");
			this.add(splitPane1, "East");
			
			//this.setVisible(true);
			
	}
	public ManagerAddTf(DefaultListModel<ScenicSpots> scModel)
	{
		this.scModel = scModel;
		initGUI();
		
	}
}

