package trip;

public class TravelItem {
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getHour() {
		return hour;
	}
	public void setHour(Integer hour) {
		this.hour = hour;
	}
	public Integer getMinutes() {
		return minutes;
	}
	public void setMinutes(Integer minutes) {
		this.minutes = minutes;
	}


	private Double price;
	private Integer hour;
	private Integer minutes;
	public TravelItem(String name, Double price, Integer hour, Integer minutes) {
		super();
		this.name = name;
		this.price = price;
		this.hour = hour;
		this.minutes = minutes;
	}
	public String toMyString()
	{
		StringBuilder aBuilder = new StringBuilder();
		aBuilder.append("��Ŀ����" + name + "/�۸�" + price + "/ʱ��: " + hour + "Сʱ" +minutes +"����");
		
		return aBuilder.toString();
	}
	
	

}

