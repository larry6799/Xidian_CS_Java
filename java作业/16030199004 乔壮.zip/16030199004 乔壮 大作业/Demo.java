package trip;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.omg.CORBA.Any;
import org.omg.CORBA.Object;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;

public class Demo extends JFrame{

	
	private final String uString= "cyys";       // �����û���
	private final String pString= "111111";       // ��������
	private boolean State;           // ��¼ϵͳ���û�̬���ǹ���Ա״̬
	private JList listSc;             // չʾ���о�����б�
	private JList listTf;             
	private DefaultListModel<String> scName;      // �洢���о��������
	private DefaultListModel<String> tfName;
	private DefaultListModel<ScenicSpots> scModel;           // ָ��洢���о���ļ���
	private DefaultListModel<ScenicSpots> travelList;     // ���мƻ���
	private DefaultListModel<String> tfListModel;         // ���ڱ���ĳ����������н�ͨ��ʽ
	private JTextField tTextField1;     
	private JList listM;     // չʾ�ƻ����б�
	private JButton managerLogin;           // �������Ա�İ�ť
	private JButton managerExit;
	private JButton managerAdd;
	private JButton managerUpdate;
	private JLabel loginState;              // չʾ��¼״̬
	private int scSelectIndex;
	private JTextArea displayArea;      // չʾĳһ�������ϸ��Ϣ
	private JButton userAddlist;
	private JButton userClearlist;
	private JButton userDisplay;
	private ScenicSpots scenicSpots;
	private JButton userDeleteOne;
	public void initGUI()
	{
		  // ��ʼ���������
		    this.setTitle("����ϵͳ");  
	        this.setLayout(new BorderLayout());
	        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	        this.setBounds(100, 100, 600,300);
	       
			
		/*******North********************/	
			JPanel jPanelNorth = new JPanel();
		
			managerLogin = new JButton("����Ա��¼");
		    managerExit = new JButton("����Ա�˳�");
			managerAdd = new JButton("����Ա����");
			managerUpdate = new JButton("����Ա�޸�");
			
			jPanelNorth.add(managerLogin);
			jPanelNorth.add(managerExit);
			jPanelNorth.add(managerAdd);
			jPanelNorth.add(managerUpdate);
		
			
	    /**************south**************************/
			
			JPanel jPanelSouth = new JPanel();
			userAddlist = new JButton("���ӵ��г̵�");
			userDisplay = new JButton("չʾ�г�");
			jPanelSouth.add(userAddlist);
			jPanelSouth.add(userDisplay);
			
			
		/***************west************************/
			JPanel jPanelWest = new JPanel();
			listSc = new JList(scName);
			listSc.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			listSc.setSelectedIndex(0);
			listSc.setVisibleRowCount(15);
			JScrollPane listScrollPaneSc = new JScrollPane(listSc);
			jPanelWest.add(listScrollPaneSc);
			
		/******************Center******************************/
			JPanel jPanelCenter = new JPanel();
			displayArea = new JTextArea(10,20);
			displayArea.setFont(new Font("Serif",Font.ITALIC, 16));
			displayArea.setLineWrap(true);
			displayArea.setWrapStyleWord(true);
			this.setVisible(true);
			JScrollPane listScrollPaneSc1 = new JScrollPane(displayArea);
			jPanelCenter.add(listScrollPaneSc1);	
			travelList = new DefaultListModel<ScenicSpots>();			
			this.add(jPanelNorth,"North");
			this.add(jPanelSouth,"South");
			this.add(jPanelWest,"West");
			this.add(jPanelCenter,"Center");
			this.setVisible(true);
			
	}
	public void initListiner()
	{
		// ������Ӧ���¼�������
		managerLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (State == false)
				{String userNameString = JOptionPane.showInputDialog("�������û���cyys");
				JPasswordField pw = new JPasswordField();
				JOptionPane.showMessageDialog(null, pw, "����������111111", JOptionPane.PLAIN_MESSAGE);
				String passwordString = pw.getText();
				
				if (userNameString.equals(uString) && passwordString.equals(pString))
				{
					State = true;
					//loginState.setText("״̬������");
				}
				else {
					JOptionPane.showMessageDialog(Demo.this, "��¼ʧ�ܣ�������û�������","warning",JOptionPane.WARNING_MESSAGE);
				}
				}
				else {
					JOptionPane.showMessageDialog(Demo.this, "�Ѿ���¼�������˳�","warning",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
	    managerExit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (State == true)
				{
					State = false;
					loginState.setText("״̬���ο�");
				}
				else {
					
				}
				
			}
		});
		managerAdd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (State == true)
				{
					Manager manager = new Manager(scModel,scName);
					manager.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(Demo.this, "���ȵ�¼","warning",JOptionPane.WARNING_MESSAGE);
				}
				
			}
		});
		managerUpdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (State == true)
				{
					ManagerAddTf manager = new ManagerAddTf(scModel);
					manager.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(Demo.this, "���ȵ�¼","warning",JOptionPane.WARNING_MESSAGE);
				}
				
			}
		});
		listSc.addListSelectionListener(new ListSelectionListener() {
			
			

			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
				scSelectIndex = listSc.getSelectedIndex();
				scenicSpots = scModel.get(scSelectIndex);
				displayArea.setText(scenicSpots.myToString());
			}
		});
		userAddlist.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (scenicSpots != null && !travelList.contains(scenicSpots))
				{
					DefaultListModel<String> tf = scenicSpots.getJiaotong();
					java.lang.Object[] oo = tf.toArray();
					String selectValue = (String) JOptionPane.showInputDialog(null,"ѡ��һ�ֽ�ͨ����","input",
							JOptionPane.INFORMATION_MESSAGE,null,oo,oo[0]);
					travelList.addElement(scenicSpots);
					tfListModel.addElement(selectValue);
				}
			}
		});
		userDisplay.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Plan plan = new Plan(travelList, tfListModel);
				String mesString = plan.displayPlan();
				JOptionPane.showMessageDialog(Demo.this, mesString);
			}
		});
	}
	public Demo(DefaultListModel<ScenicSpots> database)
	{
		tfListModel = new DefaultListModel<String>();
		State = false;
		scModel = database;
		scName = new DefaultListModel<String>();
		initGUI();
		initListiner();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         DefaultListModel<ScenicSpots> databDefaultListModel = new DefaultListModel<ScenicSpots>();
         Demo gui = new Demo(databDefaultListModel);
        
	}

}

